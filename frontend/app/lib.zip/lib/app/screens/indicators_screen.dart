// recommendations_screen.dart
import 'package:flutter/material.dart';
import 'moving_averages/ma_input_screen.dart';
import 'rsi/rsi_input_screen.dart';
import 'adx/adx_input_screen.dart';
import 'macd/macd_input_screen.dart';
import 'stochastic/stochastic_input_screen.dart';
import 'williamsr/williamsr_input_screen.dart';
import 'bollinger_bands/bollinger_bands_input_screen.dart';
import 'parabolic_sar/parabolic_sar_input_screen.dart';

class IndicatorScreen extends StatelessWidget {
  final String symbol;

  IndicatorScreen({required this.symbol});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 8,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Indicators for $symbol'),
          bottom: TabBar(
            isScrollable: true,
            tabs: [
              Tab(text: 'ADX'),
              Tab(text: 'Bollinger Bands'),
              Tab(text: 'MACD'),
              Tab(text: 'MA'),
              Tab(text: 'Parabolic SAR'),
              Tab(text: 'RSI'),
              Tab(text: 'Stochastic'),
              Tab(text: 'Williams %R'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            ADXIndicatorScreen(symbol: symbol),
            BollingerBandsIndicatorScreen(symbol: symbol),
            MACDIndicatorScreen(symbol: symbol),
            MAIndicatorScreen(symbol: symbol),
            ParabolicSARIndicatorScreen(symbol: symbol),
            RSIIndicatorScreen(symbol: symbol),
            StochasticIndicatorScreen(symbol: symbol),
            WilliamsRIndicatorScreen(symbol: symbol),
          ],
        ),
      ),
    );
  }
}
